#!/usr/bin/env python3
"""BISE Matric Results 2026 - Semester Project Phase I
Main Orchestration Script.

Usage:
  python3 main.py                  # Crawls all 20 boards across Pakistan
  python3 main.py --demo           # Fast demo mode (generates 1,000 records across all 4 storages)
  python3 main.py --board Lahore   # Crawl only a specific board
  python3 main.py --inspect        # Verify all generated storage files and record counts
  python3 main.py --clean          # Clean output directory
"""

import sys
import os
import time
import argparse
import shutil
from config import BOARDS, STORAGE_BY_REGION, YEAR
from crawlers.base import Crawler
from storage.stores import SAVERS, inspect_stores

def print_banner():
    banner = f"""
================================================================================
          BISE MATRIC RESULTS {YEAR} - SEMESTER PROJECT PHASE I
               Distributed Heterogeneous Database Extraction
================================================================================
  Target: 20 Boards Across Pakistan (Matric Secondary School Certificate)
  Storage Routing:
    - Punjab & Federal (8 Boards)  -> MS Access Database (.accdb / .sql)
    - KPK (6 Boards)               -> TXT Flat Files & Gazette (.txt)
    - Sindh (4 Boards)             -> MySQL Relational Database (.sql)
    - AJK & Balochistan (2 Boards) -> Excel Spreadsheets (.xlsx)
================================================================================
"""
    print(banner)

def clean_output():
    """Removes output directory contents to start fresh."""
    if os.path.exists("output"):
        shutil.rmtree("output")
    os.makedirs("output", exist_ok=True)
    print("  [OK] Output directory cleaned.")

def main():
    parser = argparse.ArgumentParser(
        description=f"BISE Matric Results {YEAR} - Heterogeneous Crawler & Storage Engine"
    )
    parser.add_argument("--demo", action="store_true",
                        help="Run in demo mode with intelligent simulated data generator")
    parser.add_argument("--board", type=str, default=None,
                        help="Target specific board by name (e.g. Lahore, Karachi, Peshawar)")
    parser.add_argument("--inspect", "--verify", action="store_true",
                        help="Inspect and verify all generated output files and records")
    parser.add_argument("--clean", "--reset", action="store_true",
                        help="Clean the output folder before running")
    parser.add_argument("--records", type=int, default=None,
                        help="Limit number of records per board (default: all 50 per board)")

    args = parser.parse_args()

    print_banner()

    if args.clean:
        clean_output()
        if not args.demo and not args.board and not args.inspect:
            return

    if args.inspect:
        inspect_stores()
        return

    # Filter boards if specific board requested
    target_boards = BOARDS
    if args.board:
        target_boards = [b for b in BOARDS if b["name"].lower() == args.board.lower()]
        if not target_boards:
            print(f"Error: Board '{args.board}' not found.")
            print(f"Available boards ({len(BOARDS)}): {', '.join(b['name'] for b in BOARDS)}")
            sys.exit(1)

    mode_label = "DEMO SIMULATION" if args.demo else "LIVE CRAWLER (WITH AUTO-FALLBACK)"
    print(f"[*] Starting extraction in [{mode_label}] mode for {len(target_boards)} board(s)...")
    print("-" * 80)

    total_records = 0
    start_time = time.time()

    for idx, b in enumerate(target_boards, 1):
        board_name = b["name"]
        region = b["region"]
        storage_type = STORAGE_BY_REGION.get(region, "txt")

        print(f"[{idx:02d}/{len(target_boards):02d}] Fetching {board_name:<14} ({region:<11}) -> Storage: {storage_type.upper()}")

        crawler = Crawler(b, demo=args.demo, max_records=args.records)
        rows = crawler.run()

        saver_func = SAVERS.get(storage_type)
        if saver_func:
            try:
                dest_info = saver_func(board_name, rows)
                print(f"       -> Saved {len(rows)} records | {dest_info}")
                total_records += len(rows)
            except Exception as e:
                print(f"       -> STORAGE ERROR: {e}")
        else:
            print(f"       -> Unknown storage type '{storage_type}'")

        print()

    elapsed = time.time() - start_time
    print("=" * 80)
    print(f"[COMPLETED] Extracted {total_records} records across {len(target_boards)} board(s) in {elapsed:.2f}s")
    print("=" * 80)

    # Show verification report summary automatically
    inspect_stores()

    print("\nPresentation Tip: To show files to Sir, check the 'output/' directory:")
    print("  1. Punjab & Federal -> output/punjab_federal.accdb & output/punjab_federal.sql")
    print("  2. KPK              -> output/kpk_txt/ (Data files & Gazettes)")
    print("  3. Sindh            -> output/sindh_mysql.sql & output/sindh_mysql.db")
    print("  4. AJK/Balochistan  -> output/excel/ (*.xlsx workbooks)\n")

if __name__ == "__main__":
    main()
