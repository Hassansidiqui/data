"""BISE Matric Results 2026 - Configuration
Defines 20 BISE Boards across Pakistan and storage routing:
- Punjab & Federal (8 boards)  -> MS Access (output/punjab_federal.accdb)
- KPK (6 boards)               -> TXT Files (output/kpk_txt/*.txt)
- Sindh (4 boards)             -> MySQL Database (bise_results.matric_results)
- AJK & Balochistan (2 boards) -> Excel Files (output/excel/*.xlsx)
"""

YEAR = 2026

def B(name, region, url, start=100001, end=100050, method="GET", fields=None):
    return dict(
        name=name,
        region=region,
        url=url,
        start=start,
        end=end,
        method=method,
        fields=fields or {}
    )

# Regular expressions for parsing real BISE result HTML pages
DEFAULT_FIELDS = {
    "name":        r"Name\s*[:\-]?\s*([A-Za-z .]+)",
    "father":      r"Father'?s?\s*Name\s*[:\-]?\s*([A-Za-z .]+)",
    "group":       r"Group\s*[:\-]?\s*([A-Za-z /()]+)",
    "total_marks": r"(?:Total\s*Marks?|Obtained\s*Marks?|Marks)\s*[:\-]?\s*(\d+)",
    "grade":       r"Grade\s*[:\-]?\s*([A-Z][+1]?)",
    "status":      r"\b(PASS|FAIL|PROMOTED)\b",
}

# The 20 BISE Boards of Pakistan mapped across regions
BOARDS = [
    # ---- 1. Punjab (8 Boards total including Federal) -> MS Access ----
    B("Sargodha",   "Punjab",  "https://bisesargodha.edu.pk/result?roll={roll}"),
    B("Rawalpindi", "Punjab",  "https://biserwp.edu.pk/result?roll={roll}"),
    B("Gujranwala", "Punjab",  "https://bisegrw.edu.pk/result?roll={roll}"),
    B("Multan",     "Punjab",  "https://bisemultan.edu.pk/result?roll={roll}"),
    B("Sialkot",    "Punjab",  "https://bisesialkot.edu.pk/result?roll={roll}"),
    B("Lahore",     "Punjab",  "https://biselahore.com/result?roll={roll}"),
    B("Faisalabad", "Punjab",  "https://bisefsd.edu.pk/result?roll={roll}"),
    B("Federal",    "Federal", "https://fbise.edu.pk/result?roll={roll}"),

    # ---- 2. KPK (6 Boards) -> TXT Files ----
    B("Peshawar",   "KPK",     "https://bisep.edu.pk/result?roll={roll}"),
    B("Mardan",     "KPK",     "https://bisemdn.edu.pk/result?roll={roll}"),
    B("Abbottabad", "KPK",     "https://biseatd.edu.pk/result?roll={roll}"),
    B("Swat",       "KPK",     "https://biseswat.edu.pk/result?roll={roll}"),
    B("Kohat",      "KPK",     "https://bisekohat.edu.pk/result?roll={roll}"),
    B("Bannu",      "KPK",     "https://bisebannu.edu.pk/result?roll={roll}"),

    # ---- 3. Sindh (4 Boards) -> MySQL Database ----
    B("Karachi",    "Sindh",   "https://bsek.edu.pk/result?roll={roll}"),
    B("Hyderabad",  "Sindh",   "https://biseh.edu.pk/result?roll={roll}"),
    B("Nawabshah",  "Sindh",   "https://bisenawabshah.edu.pk/result?roll={roll}"),
    B("Mirpurkhas", "Sindh",   "https://bisemirpurkhas.edu.pk/result?roll={roll}"),

    # ---- 4. AJK + Balochistan (2 Boards) -> Excel Files ----
    B("AJK",        "AJK",         "https://bisemirpur.edu.pk/result?roll={roll}"),
    B("Quetta",     "Balochistan", "https://bbisequetta.edu.pk/result?roll={roll}"),
]

# Region-to-Storage Mapping as per Semester Project Whiteboard instructions
STORAGE_BY_REGION = {
    "Punjab":      "access",
    "Federal":     "access",
    "KPK":         "txt",
    "Sindh":       "mysql",
    "AJK":         "excel",
    "Balochistan": "excel",
}

# Standard column schema for Horizontal Split (Matric subjects + total marks)
COLS = [
    "board", "region", "year", "roll_no", "name", "father", "group",
    "urdu", "english", "islamiyat", "pak_studies", "maths", "physics", "chemistry", "bio_cs",
    "total_marks", "grade", "status"
]

# Database Configurations
MYSQL = dict(host="localhost", user="root", password="", database="bise_results", port=3306)
ACCESS_DB = "output/punjab_federal.accdb"
