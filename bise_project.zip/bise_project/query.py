#!/usr/bin/env python3
"""Federated Query & Analytics Engine for BISE Matric Results 2026
Allows querying across all 4 heterogeneous storage sources:
- Punjab & Federal (MS Access / SQLite Mirror)
- KPK (TXT Files)
- Sindh (MySQL / SQLite Mirror)
- AJK & Balochistan (Excel / CSV)
"""

import os
import sys
import sqlite3
import csv
import argparse

def get_federated_connection():
    """Builds an in-memory unified database aggregating all 4 storage media."""
    con = sqlite3.connect(":memory:")
    cur = con.cursor()
    cur.execute("""CREATE TABLE all_matric_results (
        board TEXT, region TEXT, year INTEGER, roll_no INTEGER,
        name TEXT, father TEXT, [group] TEXT,
        urdu INTEGER, english INTEGER, islamiyat INTEGER, pak_studies INTEGER,
        maths INTEGER, physics INTEGER, chemistry INTEGER, bio_cs INTEGER,
        total_marks INTEGER, grade TEXT, status TEXT
    )""")

    # 1. Load Punjab & Federal from SQLite mirror or CSV
    if os.path.exists("output/punjab_federal.db"):
        src = sqlite3.connect("output/punjab_federal.db")
        for row in src.execute("SELECT * FROM matric_results"):
            cur.execute("INSERT INTO all_matric_results VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)", row)
        src.close()
    elif os.path.exists("output/punjab_federal_import.csv"):
        with open("output/punjab_federal_import.csv", encoding="utf-8") as f:
            r = csv.reader(f)
            next(r)
            for row in r:
                cur.execute("INSERT INTO all_matric_results VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)", row)

    # 2. Load KPK from TXT files
    kpk_dir = "output/kpk_txt"
    if os.path.exists(kpk_dir):
        for fname in os.listdir(kpk_dir):
            if fname.endswith(".txt") and not fname.endswith("_gazette.txt"):
                with open(os.path.join(kpk_dir, fname), encoding="utf-8") as f:
                    lines = [l.strip().split("|") for l in f if l.strip()]
                    if len(lines) > 1:
                        for row in lines[1:]:
                            cur.execute("INSERT INTO all_matric_results VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)", row)

    # 3. Load Sindh from SQLite mirror
    if os.path.exists("output/sindh_mysql.db"):
        src = sqlite3.connect("output/sindh_mysql.db")
        for row in src.execute("SELECT * FROM matric_results"):
            cur.execute("INSERT INTO all_matric_results VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)", row)
        src.close()

    # 4. Load AJK & Balochistan from CSV/Excel
    excel_dir = "output/excel"
    if os.path.exists(excel_dir):
        for fname in os.listdir(excel_dir):
            if fname.endswith(".csv"):
                with open(os.path.join(excel_dir, fname), encoding="utf-8") as f:
                    r = csv.reader(f)
                    next(r)
                    for row in r:
                        cur.execute("INSERT INTO all_matric_results VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)", row)

    con.commit()
    return con

def report_summary(con):
    """Prints comprehensive provincial and board summary."""
    cur = con.cursor()
    cur.execute("""
        SELECT region, board,
               COUNT(*) as total,
               SUM(CASE WHEN status='PASS' THEN 1 ELSE 0 END) as passed,
               SUM(CASE WHEN status='FAIL' THEN 1 ELSE 0 END) as failed,
               ROUND(AVG(total_marks), 1) as avg_marks,
               MAX(total_marks) as top_marks
        FROM all_matric_results
        GROUP BY region, board
        ORDER BY region, board
    """)
    rows = cur.fetchall()

    print("\n" + "=" * 90)
    print("           BISE MATRIC RESULTS 2026 - FEDERATED SUMMARY ACROSS 20 BOARDS")
    print("=" * 90)
    print(f"{'REGION':<13} {'BOARD':<14} {'APPEARED':<10} {'PASSED':<8} {'FAILED':<8} {'PASS %':<8} {'AVG MARKS':<10} {'TOP':<6}")
    print("-" * 90)

    cur_region = None
    tot_app = tot_pass = tot_fail = 0

    for r in rows:
        region, board, app, passed, failed, avg_m, top_m = r
        pct = (passed / app * 100.0) if app else 0.0
        tot_app += app
        tot_pass += passed
        tot_fail += failed

        reg_display = region if region != cur_region else ""
        cur_region = region

        print(f"{reg_display:<13} {board:<14} {app:<10} {passed:<8} {failed:<8} {pct:<7.1f}% {avg_m:<10} {top_m:<6}")

    print("-" * 90)
    tot_pct = (tot_pass / tot_app * 100.0) if tot_app else 0.0
    print(f"{'TOTAL':<28} {tot_app:<10} {tot_pass:<8} {tot_fail:<8} {tot_pct:<7.1f}%")
    print("=" * 90 + "\n")

def search_student(con, query):
    """Searches student by roll number or name."""
    cur = con.cursor()
    is_roll = query.isdigit()
    if is_roll:
        cur.execute("SELECT * FROM all_matric_results WHERE roll_no = ?", (int(query),))
    else:
        cur.execute("SELECT * FROM all_matric_results WHERE name LIKE ?", (f"%{query}%",))
    rows = cur.fetchall()

    if not rows:
        print(f"No student found matching '{query}'.")
        return

    print(f"\nFound {len(rows)} matching student(s):")
    print("-" * 88)
    for r in rows:
        print(f"Roll No:     {r[3]} | Board: {r[0]} ({r[1]})")
        print(f"Name:        {r[4]} s/o or d/o {r[5]}")
        print(f"Group:       {r[6]}")
        print(f"Marks:       Urdu:{r[7]} Eng:{r[8]} Isl:{r[9]} Pak:{r[10]} Math:{r[11]} Phy:{r[12]} Chem:{r[13]} Bio/CS:{r[14]}")
        print(f"Total:       {r[15]}/1100 | Grade: {r[16]} | Status: {r[17]}")
        print("-" * 88)

def show_toppers(con, board=None):
    """Displays top 3 position holders."""
    cur = con.cursor()
    if board:
        cur.execute("""
            SELECT board, roll_no, name, total_marks, grade, [group]
            FROM all_matric_results
            WHERE LOWER(board) = LOWER(?)
            ORDER BY total_marks DESC LIMIT 3
        """, (board,))
    else:
        cur.execute("""
            SELECT board, roll_no, name, total_marks, grade, [group]
            FROM all_matric_results
            ORDER BY total_marks DESC LIMIT 5
        """)
    rows = cur.fetchall()

    title = f"Top Position Holders for {board.capitalize()}" if board else "Overall Top 5 Position Holders in Pakistan"
    print(f"\n{title}:")
    print("-" * 75)
    print(f"{'POS':<5} {'ROLL NO':<10} {'BOARD':<14} {'NAME':<22} {'MARKS':<8} {'GRADE':<6}")
    print("-" * 75)
    for i, r in enumerate(rows, 1):
        print(f"{i:<5} {r[1]:<10} {r[0]:<14} {r[2]:<22} {r[3]:<8} {r[4]:<6}")
    print("-" * 75 + "\n")

def interactive_shell(con):
    """Interactive SQL query prompt for viva examination."""
    print("\n--- BISE Federated Query Shell (Type SQL query or 'exit') ---")
    print("Table: all_matric_results (columns: board, region, year, roll_no, name, father, group, urdu, english, islamiyat, pak_studies, maths, physics, chemistry, bio_cs, total_marks, grade, status)\n")
    while True:
        try:
            cmd = input("bise_sql> ").strip()
            if not cmd:
                continue
            if cmd.lower() in ("exit", "quit", "q"):
                break
            cur = con.cursor()
            cur.execute(cmd)
            rows = cur.fetchall()
            if not rows:
                print("No rows returned.")
                continue
            headers = [d[0] for d in cur.description]
            print(" | ".join(headers))
            print("-" * 70)
            for r in rows[:15]:
                print(" | ".join(str(v) for v in r))
            if len(rows) > 15:
                print(f"... and {len(rows)-15} more rows.")
            print()
        except Exception as e:
            print("SQL Error:", e)

def main():
    parser = argparse.ArgumentParser(description="Query Federated BISE Results")
    parser.add_argument("--summary", action="store_true", help="Print 20 boards summary table")
    parser.add_argument("--search", type=str, help="Search by Roll No or Student Name")
    parser.add_argument("--toppers", type=str, nargs="?", const="all", help="Show toppers (overall or board name)")
    parser.add_argument("--sql", action="store_true", help="Interactive SQL shell")

    args = parser.parse_args()

    con = get_federated_connection()

    if args.search:
        search_student(con, args.search)
    elif args.toppers:
        show_toppers(con, None if args.toppers == "all" else args.toppers)
    elif args.sql:
        interactive_shell(con)
    else:
        report_summary(con)

if __name__ == "__main__":
    main()

